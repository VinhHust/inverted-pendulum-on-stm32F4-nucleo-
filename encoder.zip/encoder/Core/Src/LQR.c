#include "LQR.h"
#include <math.h>
#define DT 0.005f
#define PI 3.141592625f
#define MiliMtoM 0.001f //hệ số chuyển từ mm sang m
#define GRAVITY 9.81f

//các tham số của hệ (DÙNG CHO SWING UP)
float pendulum_mass = 0.1f;
float pendulum_length = 0.15f;
float pendulum_inertia = 0.00075f; //phần này có thể tune

//các tham số cho phần SWING UP
float k_swing = 8.0f;
float max_swing_acce = 12.0f;
float max_cart_limit = 0.25f;

//các tham số cho phần KICK START
float kick_acce = 2.5f;
float kick_time = 0.05f;
static float kick_counter = 0.0f; //static để lưu lại giá trị kick_counter để cộng dồn trong mỗi lần gọi hàm
float max_kick_speed = 5.0f;

//các tham số để tune LQR
//LQR tương ứng theta,theta',x,x'
float LQR_tune[4] = {525.2304,  96.8291,-132.2876,-137.9898};
static float reference_point = 0.0f;
static float  target_speed = 0.0f;

float max_speed = 10.0f;
float max_accel = 6.0f;
//u=-K(X-Xref)=K(Xref-X)

//bộ PD cho swing up
float k1_swing = 3.0f; //gain để kéo vị trí quanh tâm
float k2_swing = 2.0f; //gain để ko bị oscillate quá
float debug_sign_val = 0.0f; // Biến toàn cục để lôi sign_val ra ngoài
float debug_sign = 0.0f; // Biến toàn cục để lôi sign_val ra ngoài
float debug_pend_velo = 0.0f;

//filter vận tốc
float alpha = 0.8f;
static float filter_speed = 0.0f; // Biến lưu trữ vận tốc của chu kỳ trước

//hàm khởi tạo trạng thái ban đầu cho con lắc, hàm nào nhận vào con trỏ
//pendulum chỉ là tên nội bộ, khi lôi ra sử dụng thì sẽ dùng tên biến khác
void init_pendulum(InvertedPendulumTypeDef* pendulum) {
	pendulum->state = IDLE_PENDULUM;
	//con trỏ lồng con trỏ, con trỏ pendulum truy cập tới con trỏ steppẻ
	Stepper_UpdateCartFrequency(pendulum->stepper, 0);
	target_speed = 0.0f; //reset lại target speed mỗi khi từ LQR về lại IDLE
	filter_speed = 0.0f;

}
float run_pendulum(InvertedPendulumTypeDef* pendulum){
	//cập nhật dữ liệu của encoder thông qua 2 con trỏ pend_enc và cart_enc
	update_encoder_pendulum(pendulum->pend_enc); //con trỏ pendulum truy cập vào con trỏ pend_enc trỏ tới kiểu dữ liệu EncoderTypeDef
	update_encoder_cart(pendulum->cart_enc);

	switch(pendulum->state){

		//TRẠNG THÁI NGHỈ CỦA PENDULUM
		case IDLE_PENDULUM:{
			Stepper_UpdateCartFrequency(pendulum->stepper, 0);
			float current_angle = pendulum->pend_enc->angle_position;

			//TRƯỜNG HỢP 1
			if(current_angle > (PI-0.17f) || current_angle < -(PI-0.17f)){
				reference_point = pendulum->cart_enc->linear_position * MiliMtoM;
				target_speed = 0.0f; //phần này để reset nếu như mà ngã về idle từ lqr thì target speed sẽ reset về 0, đề không bị lỗi trong lần catch tiếp theo
				pendulum->state = LQR_CONTROL;
				filter_speed = 0.0f; //reset lại filterspeed lúc ở LQR dể reset lại filter speed lúc LQR
				break;
		}
			//TRƯÒNG HỢP 2
			//ấn nút PC13 trên mạch thì bay sang phần kickstart
			if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET){
				kick_counter = 0.0f;
				target_speed = 0.0f;
				filter_speed = 0.0f;
				pendulum->state = KICK_START;
 			}
			break;
	}

		//TRẠNG THÁI KICKSTART CẤP GIA TỐC BAN ĐẦU
		case KICK_START:{
			kick_counter += DT; //CỘNG DỒN MỖI LẦN GỌI HÀM RUN_PENDULUM TRONG INTERRUPT Ở MAIN
			target_speed = target_speed + (kick_acce * DT); //tích phân về vận tốc

		if (kick_counter > kick_time){
			pendulum -> state = SWING_UP; //quá 8 chu kì lấy mẫu thì bay sang swing up
			break;
		}
		break;
		}

		//TRẠNG THÁI SWING UP
		case SWING_UP:{
			float current_cart_pos = pendulum->cart_enc->linear_position * MiliMtoM;
			float current_angle = pendulum->pend_enc->angle_position;
			float current_cart_vel = pendulum->cart_enc->linear_speed * MiliMtoM;

			//chuyển trạng thái sang cân bằng
			if(current_angle > (PI-0.17f) || current_angle < -(PI-0.17f)){
							reference_point = pendulum->cart_enc->linear_position * MiliMtoM;
							target_speed = 0.0f; //phần này để reset nếu như mà ngã về idle từ lqr thì target speed sẽ reset về 0, đề không bị lỗi trong lần catch tiếp theo
							pendulum->state = LQR_CONTROL;
							//nếu như vung đến vùng bắt thì sẽ bật bắt
				break;}
			float pend_velo = pendulum->pend_enc->angle_speed;

			//các thành phần trong năng lượng của HỆ
			float mlsquare = pendulum_mass * pendulum_length * pendulum_length; 	  // ml^2 //thử bỏ ml bình này đi
			float Ek =  0.5f * (pendulum_inertia) * (pend_velo*pend_velo); // 0.5(I+ml^2)
			float Ep = pendulum_mass * GRAVITY *pendulum_length * (1.0f - cosf(current_angle)); // mgl(1-cos(theta))
			float E = Ek + Ep;

			//năng lượng MONG MUỐN
			float Er = 2.0f * pendulum_mass * GRAVITY * pendulum_length; //năng lương mong muốn là 2mgl
			float sign = pend_velo * cosf(current_angle);
			float sign_val = 0.0f;

			if(sign>0.0f){ //thử tăng giới hạn đổi dấu của sign
				sign_val = 1;
			}
			else if(sign<-0.0f){
				sign_val = -1;
			}
			else{
				sign_val = 0; //nếu như nằm ở khoảng giữa thì = 0 luôn để ko bị nhiễu
			}
			debug_sign = sign;
			debug_sign_val = sign_val;
			debug_pend_velo = pend_velo;
			//a = k.(E-Eo).sign(theta'.costheta)
			float aswing = k_swing * (E - Er) * sign_val;


			//thêm bộ PD để giữ phần swing up loanh quanh tâm
			aswing += (-k1_swing * current_cart_pos) - (k2_swing * current_cart_vel); //cộng thêm bộ PD

			//giới hạn vận tốc swing
			if (aswing>max_swing_acce){
				aswing = max_swing_acce;
			}
			else if (aswing<-max_swing_acce){
				aswing = -max_swing_acce;
			}
			pendulum ->current_accel = aswing;
			target_speed = target_speed + (aswing * DT); //tích phân về vận tốc

			//giới hạn vận tốc
			if(target_speed > max_speed){
							target_speed = max_speed;}
							else if(target_speed<-max_speed){
							target_speed = -max_speed;
						}
			break;
		}

		//TRẠNG THÁI CÂN BẰNG
		case LQR_CONTROL:{
			float current_angle = pendulum->pend_enc->angle_position;
			//phần này để bảo vệ cơ khí nếu con lắc rủ xuống thấp quá
			if(fabsf(current_angle) < (PI*0.75f)){
				pendulum->state = IDLE_PENDULUM;
				break;
			}
			float lqr_giatoc = 0.0f;

			//VỊ TRÍ GÓC
			if (current_angle > 0){
				lqr_giatoc += LQR_tune[0]*(PI-current_angle);}
			else{
				lqr_giatoc += LQR_tune[0]*(-PI-current_angle);
				}
			//VẬN TỐC GÓC
			lqr_giatoc +=LQR_tune[1]*(0-pendulum->pend_enc->angle_speed);

			//đổi đơn vị của vận tốc và vị trí cart sang hệ mét
			float current_cart_pos = pendulum->cart_enc->linear_position * MiliMtoM;
			float current_cart_vel = pendulum->cart_enc->linear_speed * MiliMtoM;

			//VỊ TRÍ CART
			lqr_giatoc += LQR_tune[2] * (reference_point - current_cart_pos);
			lqr_giatoc += LQR_tune[3] * (0 - current_cart_vel);

			//GIỚI HẠN GIA TỐC
			if (lqr_giatoc > max_accel) {
			    lqr_giatoc = max_accel;
			} else if (lqr_giatoc < -max_accel) {
			    lqr_giatoc = -max_accel;
			}

			pendulum ->current_accel = lqr_giatoc; //ghi biến cục bộ vào currentaccel để debug
			//TÍCH PHÂN THÀNH VẬN TỐC v = v0 + a.dT
			target_speed = target_speed + (lqr_giatoc * DT);

			//GIOI HẠN VẬN TỐC TỐI ĐA
			if(target_speed > max_speed){
				target_speed = max_speed;}
				else if(target_speed<-max_speed){
				target_speed = -max_speed;
			}
			break;
		}
	}
	//bộ lọc EMA cho vận tốc
	//alpha lớn thì ưu tiên vận tốc mới, alpha nhỏ thì ưu tiên vận tốc cũ
	filter_speed = (alpha*target_speed) + ((1.0f-alpha)*filter_speed); //filter speed là vận tốc cũ, target speed là vận tốc mới
	return filter_speed;
}
